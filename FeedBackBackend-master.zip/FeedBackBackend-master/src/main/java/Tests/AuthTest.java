package Tests;

import DTO.UserDTO;
import Login.BrugerautorisationRMI;
import RESTServices.LoginService;
import org.junit.Test;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import static org.testng.Assert.fail;

public class AuthTest {


        @Test
        public void AuthTest(){
            LoginService loginService = new LoginService();
            UserDTO userDTO = new UserDTO();
            userDTO.setPassword("Kode123");
            userDTO.setUsername("Trolund");
            loginService.getLogin(userDTO);
        }



    @Test
    public void AuthTest2(){
        BrugerautorisationRMI rmi = new BrugerautorisationRMI();
        try {
            if(!rmi.tjekCredentials("s161791", "kode123")){
                fail();
            }
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (NotBoundException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        }
    }

}
