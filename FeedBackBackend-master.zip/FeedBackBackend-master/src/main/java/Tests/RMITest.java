package Tests;

import DTO.MeetingDTO;
import Firebase.EnumCollectionMapException;
import Firebase.IFirebaseFacilitator;
import org.junit.Test;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.concurrent.ExecutionException;

public class RMITest {

    @Test
    public void test(){


       // RMIServer.getInstance().startRMIServer();

       String url = "rmi://localhost:1617/Feedback-backend";

        //http://130.225.170.204:11791/

        //String url = "rmi://130.225.170.204:16179/RMI";
       // String url = "rmi://130.225.170.204:1617/Feedback-backend";

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        IFirebaseFacilitator fire = null;
        try {
            fire = (IFirebaseFacilitator) Naming.lookup(url);



        } catch (NotBoundException e) {
            e.printStackTrace();
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        }

        try {
           // System.out.println("hvad er bmødID?" +);
            String id = "3rlu";
            MeetingDTO meetingDTO = fire.getMeetingByID(id);
            System.out.println(fire.HentVirksomhedMedId(0).getNavn());

        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (RemoteException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }

    }


}
