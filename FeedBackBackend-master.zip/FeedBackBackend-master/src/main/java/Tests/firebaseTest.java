package Tests;

import DTO.*;
import Firebase.EnumCollectionMapException;
import Firebase.FirebaseFacilitator;
import org.junit.Test;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;

import static org.testng.Assert.assertEquals;

public class firebaseTest {

    private String testMeetingID = "VIe0";

    @Test
    public void tilføjVirksomhed(){
        FirebaseFacilitator firebaseobj = FirebaseFacilitator.getInstance();
        try {
            firebaseobj.tilføjVirksomhed(1000, "TEST VirksomhedService");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void hentVirksomhed(){
        FirebaseFacilitator firebaseobj = FirebaseFacilitator.getInstance();
        try {
            try {
               Virksomhed virksomhed = firebaseobj.HentVirksomhedMedId(1000);
                System.out.println("navn: " + virksomhed.getNavn() + " ID: " + virksomhed.getVirksomhedsID());
            } catch (ExecutionException e) {
                e.printStackTrace();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void opretMøde(){
        FirebaseFacilitator firebaseobj = FirebaseFacilitator.getInstance();
        try {
            firebaseobj.opretmode(new MeetingDTO("Testmødev4", "At teste?", "DTU lyngby 303A, lokale 4",28 , 4,  2019, new Date(), new Date(), "Trolund"));
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void getMeetingByID(){
        FirebaseFacilitator firebaseobj = FirebaseFacilitator.getInstance();
        try {
            try {
                MeetingDTO meetingDTO = firebaseobj.getMeetingByID(testMeetingID);
                System.out.println("navn: " + meetingDTO.getName() + " ID: " + meetingDTO.getMeetingID());
                System.out.println(meetingDTO.toString());
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void getAllMeetings(){
        FirebaseFacilitator firebaseobj = FirebaseFacilitator.getInstance();
        try {
            try {
                ArrayList<MeetingDTO> list = firebaseobj.getAllMeetings();
                System.out.println(list);
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void getAllMeetingsById(){
        FirebaseFacilitator firebaseobj = FirebaseFacilitator.getInstance();
        try {
            try {
                ArrayList<MeetingDTO> list3 = firebaseobj.getAllMeetingsForUser("0", null);
                System.out.println(list3);
                ArrayList<MeetingDTO> list = firebaseobj.getAllMeetingsForUser("0", true);
                System.out.println(list);
                ArrayList<MeetingDTO> list2 = firebaseobj.getAllMeetingsForUser("0", false);
                System.out.println(list2);
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }


    @Test
    public void setStateOfMeetingTest(){
        FirebaseFacilitator firebaseobj = FirebaseFacilitator.getInstance();
        String id = testMeetingID;
            try {
                System.out.println("xxxxx");
                firebaseobj.setStateOfMeeting(id, 1);
               Thread.sleep(1000);
                MeetingDTO meetingDTO = firebaseobj.getMeetingByID(id);

                assertEquals(meetingDTO.getState(), 1);

                firebaseobj.setStateOfMeeting(id ,0 );
                Thread.sleep(1000);
                meetingDTO = firebaseobj.getMeetingByID(id);

                assertEquals(meetingDTO.getState(), 0);

                firebaseobj.setStartTimeOfMeeting(id);
                firebaseobj.setStateOfMeeting(id, 1);
                Thread.sleep(1000);
                meetingDTO = firebaseobj.getMeetingByID(id);

                assertEquals(meetingDTO.getState(), 1);

                firebaseobj.setEndTimeOfMeeting(id);
                firebaseobj.setStateOfMeeting(id, 2);
                Thread.sleep(1000);
                meetingDTO = firebaseobj.getMeetingByID(id);

                assertEquals(meetingDTO.getState(), 2);

            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
    }

    @Test
    public void setFeedbackTEST(){

        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
       FeedbackDTO feedbackDTO =  new FeedbackDTO();
       feedbackDTO.setVote(0);
       feedbackDTO.setComment("Dette er en test");
       FeedbackBatchDTO feedbackBatchDTO = new FeedbackBatchDTO();
       feedbackBatchDTO.setFeedback(new ArrayList<>(1));
       feedbackBatchDTO.getFeedback().add(feedbackDTO);
       feedbackBatchDTO.setMeetingID(testMeetingID);

        try {
            fire.givFeedback(feedbackBatchDTO);
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }
    }

    @Test
    public void textOfOrdererFeedback(){
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        try {
            ArrayList<CommentDTO> feedbackBatchDTOS = fire.getOrderedFeedback(testMeetingID);
            System.out.println(feedbackBatchDTOS);

            for (CommentDTO item: feedbackBatchDTOS) {
                System.out.println(item.getQuestion());
                for (String feedback: item.getComments()) {
                    System.out.println(feedback);
                }
            }

        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void textGetQ(){
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        try {
            System.out.println(fire.getquestions("4o80NWUXOyYcyJE47ufx").getQuestions().toString());

        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }

    }


    @Test
    public void textGetQnew(){
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        try {
            System.out.println(fire.getQuestionsByMeetingID(testMeetingID));
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }

    }

    @Test
    public void setQ(){
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        try {
            List<String> list = new ArrayList<>();
            list.add("Q1");
            list.add("Q2");
            fire.setCustomQuestions(list);
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }

    }



}
