package Firebase;

public class EnumCollectionMapException extends Exception {

    public EnumCollectionMapException(String message) {
        super(message);
    }

}