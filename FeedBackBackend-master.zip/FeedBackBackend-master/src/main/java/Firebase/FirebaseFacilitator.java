package Firebase;

import DTO.*;
import com.google.api.core.ApiFuture;
import com.google.api.core.ApiFutures;
import com.google.auth.oauth2.GoogleCredentials;
import com.google.cloud.firestore.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.*;
import com.google.firebase.cloud.FirestoreClient;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.FileInputStream;
import java.io.IOException;
import java.text.ParseException;
import java.util.*;
import java.util.concurrent.ExecutionException;

enum CollectionKeys {
    USERS,
    FEEDBACK,
    MEETINGS,
    QUESTIONS
}

public class FirebaseFacilitator implements IFirebaseFacilitator {

    private static FirebaseFacilitator single_instance = null;

    private FirebaseFacilitator() {

        try {
            init();
        } catch (IOException e) {
            System.err.println("Firebase fejlet.");
            e.printStackTrace();
        }
    }

    public synchronized static FirebaseFacilitator getInstance() {
        if (single_instance == null)
            single_instance = new FirebaseFacilitator();

        return single_instance;
    }


    public synchronized void init() throws IOException {
        FileInputStream serviceAccount = null;
        //  System.out.println("Working Directory = " +
        //         System.getProperty("user.dir"));

        //serviceAccount = new FileInputStream("KEYS/feedbackapp-2dacb-firebase-adminsdk-ud38x-3df2d22128.json");
        System.out.println("Working Directory = " + System.getProperty("user.dir"));
        serviceAccount = new FileInputStream("key.json");
//https://feedbackapp-2dacb.firebaseio.com/
        FirebaseOptions options = null;

        options = new FirebaseOptions.Builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                .setDatabaseUrl("https://feedbackdb-9c056.firebaseio.com")
                .build();
// https://feedback-61121.firebaseio.com
        FirebaseApp.initializeApp(options);
    }

    private String CollectionMap(CollectionKeys keys) throws EnumCollectionMapException {
        switch (keys) {
            case FEEDBACK:
                return "Feedback";
            case USERS:
                return "Users";
            case MEETINGS:
                return "Meetings";
            case QUESTIONS:
                return "Questions";
        }
        throw new EnumCollectionMapException("Enum er værdi ikke rigtig.");
    }

    public void tilføjVirksomhed(int virksomhedsID, String navn) throws InterruptedException {

        Firestore db = FirestoreClient.getFirestore();
        CollectionReference docRef = db.collection("Virksomhed");

        List<ApiFuture<WriteResult>> futures = new ArrayList<>();

        futures.add(docRef.document(virksomhedsID + "").set(new Virksomhed(virksomhedsID, navn)));

        DocumentSnapshot document = null;
        try {
            ApiFutures.allAsList(futures).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    public void getMeetingCounter() {
        Firestore db = FirestoreClient.getFirestore();
        // DocumentReference docRef = db.collection("Meetings").document("root").get();
    }

    public Virksomhed HentVirksomhedMedId(int id) throws InterruptedException, ExecutionException {
        Firestore db = FirestoreClient.getFirestore();
        DocumentReference docRef = db.collection("Virksomhed").document(id + "");
// asynchronously retrieve the document
        ApiFuture<DocumentSnapshot> future = docRef.get();
// block on response
        DocumentSnapshot document = future.get();
        Virksomhed virksomhed = null;
        if (document.exists()) {
            // convert document to POJO
            virksomhed = document.toObject(Virksomhed.class);
            System.out.println(virksomhed.getNavn());
        } else {
            System.out.println("No such document!");
        }
        return virksomhed;
    }

    public void opretmode(MeetingDTO meetingDTO) throws ParseException, EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();
        CollectionReference docRef = db.collection(CollectionMap(CollectionKeys.MEETINGS));

        List<ApiFuture<WriteResult>> futures = new ArrayList<>();

        String id = makeUUID();

        // MeetingDTO meetingDTO = new MeetingDTO("Testmøde", "At teste?", "DTU lyngby 303A, lokale 4",28 , 4,  2019, "12:00", "12:15");
        meetingDTO.setMeetingID(id);

        if (meetingDTO.getExpectedDuration() == null && meetingDTO.getStartTime() != null && meetingDTO.getEndTime() != null) {
            setDuration(id, meetingDTO.getStartTime(), meetingDTO.getEndTime());
        } else if (meetingDTO.getExpectedDuration() != null && meetingDTO.getStartTime() != null && meetingDTO.getEndTime() == null) {
            /*
            Calendar calendar = Calendar.getInstance();

            System.out.println(meetingDTO.getStartTime());
            System.out.println(meetingDTO.getExpectedDuration());

            Date date = new SimpleDateFormat("DD:MM:YYYY HH:mm").parse(meetingDTO.getStartTime());
            Date time  =new SimpleDateFormat("HH:MM:SS").parse(meetingDTO.getExpectedDuration());

            Date utilDate = addHoursToJavaUtilDate(date, time.getHours(), time.getMinutes());

            DateFormat dateFormat = new SimpleDateFormat("DD:MM:YYYY HH:mm");

            String strDate = dateFormat.format(utilDate);

            meetingDTO.setEndTime(strDate);
            */
        }

        futures.add(docRef.document(id).set(meetingDTO));

        DocumentSnapshot document = null;
        try {
            try {
                ApiFutures.allAsList(futures).get();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        } catch (ExecutionException e) {
            e.printStackTrace();
        }
    }

    public Date addHoursToJavaUtilDate(Date date, int hours, int min) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        calendar.add(Calendar.HOUR_OF_DAY, hours);
        calendar.add(Calendar.MINUTE, min);
        return calendar.getTime();
    }

    private boolean setDuration(String id, Date time1, Date time2) throws ParseException, EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();
        Map<String, Object> docData = new HashMap<>();
        docData.put("expectedDuration", calDuration(time1, time2));

        ApiFuture<WriteResult> writeResult =
                db
                        .collection(CollectionMap(CollectionKeys.MEETINGS))
                        .document(id)
                        .set(docData, SetOptions.merge());


        return true;
    }

    private String calDuration(Date time1, Date time2) {
        // Date date1= new SimpleDateFormat("DD:MM:YYYY HH:mm").parse(time1);
        //Date date2= new SimpleDateFormat("DD:MM:YYYY HH:mm").parse(time2);
        long diff = time2.getTime() - time1.getTime();

        long diffMinutes = diff / (60 * 1000) % 60;
        long diffHours = diff / (60 * 60 * 1000) % 24;

        return diffHours + ":" + diffMinutes;
    }

    public MeetingDTO getMeetingByID(String id) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();

        DocumentReference docRef = db.collection(CollectionMap(CollectionKeys.MEETINGS)).document(id + "");
// asynchronously retrieve the document
        ApiFuture<DocumentSnapshot> future = docRef.get();
// block on response
        DocumentSnapshot document = future.get();

        MeetingDTO meetingDTO = null;
        if (document.exists()) {
            // convert document to POJO
            meetingDTO = document.toObject(MeetingDTO.class);
            //   System.out.println(Integer.toString(meetingDTO.getName()));
        } else {
            System.out.println("No such document!");
        }

        return meetingDTO;
    }


    public ArrayList<MeetingDTO> getAllMeetings() throws InterruptedException, ExecutionException, EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();

        ArrayList<MeetingDTO> listToretun = new ArrayList<>();

        ApiFuture<QuerySnapshot> docRef = db.collection(CollectionMap(CollectionKeys.MEETINGS)).get();

        QuerySnapshot future = docRef.get();

        for (Iterator<QueryDocumentSnapshot> iter = future.iterator(); iter.hasNext(); ) {
            QueryDocumentSnapshot element = iter.next();

            MeetingDTO meetingDTO = element.toObject(MeetingDTO.class);

            listToretun.add(meetingDTO);
        }
        return listToretun;
    }

    public ArrayList<MeetingDTO> getAllMeetingsForUser(String userid, Boolean done) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();

        ArrayList<MeetingDTO> listToretun = new ArrayList<>();

        ApiFuture<QuerySnapshot> docRef = db.collection(CollectionMap(CollectionKeys.MEETINGS)).get();

        ApiFuture<QuerySnapshot> snapshotApiFuture = null;
        if (done == null) { // få alle møder fra brugeren
            snapshotApiFuture = docRef.get().getQuery().whereEqualTo("createdById", userid).get();
        } else if (done) { // få alle afholdte møder
            snapshotApiFuture = docRef.get().getQuery().whereEqualTo("createdById", userid).whereGreaterThanOrEqualTo("state", 2).get();
        } else { // få alle ikke afholdte møder.
            snapshotApiFuture = docRef.get().getQuery().whereEqualTo("createdById", userid).whereLessThan("state", 2).get();
        }

        QuerySnapshot data = snapshotApiFuture.get();

        for (Iterator<QueryDocumentSnapshot> iter = data.iterator(); iter.hasNext(); ) {
            QueryDocumentSnapshot element = iter.next();

            MeetingDTO meetingDTO = element.toObject(MeetingDTO.class);

            listToretun.add(meetingDTO);
        }
        return listToretun;
    }


    public void setStateOfMeeting(String id, int state) throws ExecutionException, InterruptedException, EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();
        Map<String, Object> docData = new HashMap<>();
        docData.put("state", state);
        // docData.put("name", "state-test");
        // ApiFuture<QuerySnapshot> snapshotApiFuture = docRef.get().getQuery().whereEqualTo("createdById", userid).whereEqualTo("userMeetingID", id).get();
        ApiFuture<WriteResult> writeResult =
                db
                        .collection(CollectionMap(CollectionKeys.MEETINGS))
                        .document(id)
                        .set(docData, SetOptions.merge());
    }

    public Date setStartTimeOfMeeting(String id) throws ExecutionException, InterruptedException {
        Firestore db = FirestoreClient.getFirestore();
        Map<String, Object> docData = new HashMap<>();
        Date date = new Date(System.currentTimeMillis());
        docData.put("realStartTime", date);

        ApiFuture<WriteResult> writeResult =
                db
                        .collection("Meetings")
                        .document(id)
                        .set(docData, SetOptions.merge());
        return date;
    }

    public Date setEndTimeOfMeeting(String id) throws ExecutionException {
        Firestore db = FirestoreClient.getFirestore();
        Map<String, Object> docData = new HashMap<>();
        Date date = new Date(System.currentTimeMillis());
        docData.put("realendTime", date);

        ApiFuture<WriteResult> writeResult =
                db
                        .collection("Meetings")
                        .document(id)
                        .set(docData, SetOptions.merge());
        return date;
    }

    private String getRandomID() {
        String SALTCHARS = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
        StringBuilder salt = new StringBuilder();
        Random rnd = new Random();
        while (salt.length() < 4) { // length of the random string.
            int index = (int) (rnd.nextFloat() * SALTCHARS.length());
            salt.append(SALTCHARS.charAt(index));
        }
        String saltStr = salt.toString();
        return saltStr;
    }

    protected String makeUUID() {
        String newID = null;
        Firestore db = FirestoreClient.getFirestore();
        ApiFuture<DocumentSnapshot> docRef = null;
        do {
            newID = getRandomID();
            docRef = db.collection("Meetings").document(newID).get();
        } while (docRef == null);

        return newID;
    }

    private String makeUUIDQUESTIONS() throws EnumCollectionMapException {
        String newID = null;
        Firestore db = FirestoreClient.getFirestore();
        ApiFuture<DocumentSnapshot> docRef = null;
        do {
            newID = getRandomID();
            docRef = db.collection(CollectionMap(CollectionKeys.QUESTIONS)).document(newID).get();
        } while (docRef == null);

        return newID;
    }


    public void givFeedback(FeedbackBatchDTO batchDTO) throws EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();
        CollectionReference docRef = db.collection(CollectionMap(CollectionKeys.FEEDBACK));

        List<ApiFuture<WriteResult>> futures = new ArrayList<>();

        futures.add(docRef.document().set(batchDTO));
        //System.out.println(futures.get(0));
    }

    public ArrayList<FeedbackBatchDTO> getFeedback(String id) throws ExecutionException, InterruptedException, EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();

        ArrayList<FeedbackBatchDTO> feedbackBatchDTOArrayList = new ArrayList<>();

        ApiFuture<QuerySnapshot> docRef = db.collection(CollectionMap(CollectionKeys.FEEDBACK)).whereEqualTo("meetingID", id).get();
        QuerySnapshot data = docRef.get();

        for (Iterator<QueryDocumentSnapshot> iter = data.iterator(); iter.hasNext(); ) {
            QueryDocumentSnapshot element = iter.next();

            FeedbackBatchDTO feedbackbatchDTO = element.toObject(FeedbackBatchDTO.class);

            feedbackBatchDTOArrayList.add(feedbackbatchDTO);
        }
        return feedbackBatchDTOArrayList;
    }

    public boolean deleteMeeting(String id) throws EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();
        db.collection(CollectionMap(CollectionKeys.MEETINGS)).document(id).delete();
        return true;
    }

    public boolean deleteUser(String id) throws EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();
        db.collection(CollectionMap(CollectionKeys.USERS)).document(id).delete();
        return true;
    }

    public ArrayList<CommentDTO> getOrderedFeedback(String id) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        ArrayList<FeedbackBatchDTO> feedbackBatchDTOS = getFeedback(id);
        MeetingDTO meetingDTO = getMeetingByID(id);

        ArrayList<String> questions = getquestions(meetingDTO.getQuestionsID()).getQuestions();

        // setup af retur liste....
        ArrayList<CommentDTO> returnList = new ArrayList<>();

        for (String q : questions) {
            CommentDTO dto = new CommentDTO();
            dto.setQuestion(q);
            returnList.add(dto);
        }

        // fordeling af data.

        for (int i = 0; i < feedbackBatchDTOS.size(); i++) {
            FeedbackBatchDTO feedbackBatchDTO = feedbackBatchDTOS.get(i);

            for (int j = 0; j < feedbackBatchDTO.getFeedback().size(); j++) {
                if (j <= questions.size()) {
                    FeedbackDTO feedbackDTO = feedbackBatchDTO.getFeedback().get(j);
                    String comment = feedbackDTO.getComment();
                    if (comment.length() > 1) {
                        returnList.get(j).getComments().add(comment);
                    }
                }
            }
        }

        List<CommentDTO> removeList = new ArrayList<>();
        for (CommentDTO item : returnList) {  // send ikke spørgsmål uden kommentare til.
            if (item.getComments().isEmpty()) {
                removeList.add(item);
            }
        }
        returnList.removeAll(removeList); // får fejl hvis jeg sletter dem direkte i return list --> java.util.ConcurrentModificationException

        return returnList;
    }

    public ArrayList<String> getQuestionsByMeetingID(String id) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        MeetingDTO meetingDTO = getMeetingByID(id);
        ArrayList<String> questions;
        if (meetingDTO.getQuestionsID() == null) {
            String defultQuestionsID = "4o80NWUXOyYcyJE47ufx";
            questions = getquestions(defultQuestionsID).getQuestions();
        } else {
            questions = getquestions(meetingDTO.getQuestionsID()).getQuestions();
        }
        return questions;
    }

    public String setCustomQuestions(List<String> questionsArray) throws EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();
        CollectionReference docRef = db.collection(CollectionMap(CollectionKeys.QUESTIONS));

        QuestionsDTO dto = new QuestionsDTO();
        dto.setQuestions((ArrayList<String>) questionsArray);

        String id = makeUUIDQUESTIONS();
        docRef.document(id).set(dto);
        return id;
    }

    public QuestionsDTO getquestions(String id) throws EnumCollectionMapException, ExecutionException, InterruptedException {

        Firestore db = FirestoreClient.getFirestore();

        ArrayList<String> listToretun = new ArrayList<>();

        DocumentReference docRef = db.collection(CollectionMap(CollectionKeys.QUESTIONS)).document(id);

        ApiFuture<DocumentSnapshot> future = docRef.get();
        DocumentSnapshot document = future.get();

        QuestionsDTO questionsDTO = null;
        if (document.exists()) {
            // convert document to POJO
            questionsDTO = document.toObject(QuestionsDTO.class);
            //   System.out.println(Integer.toString(meetingDTO.getName()));
        } else {
            System.out.println("No such document!");
        }

        return questionsDTO;

    }

    // checker om brugeren står i systemet via Email
    public boolean checkOmBrugerenFindes(String email) throws FirebaseAuthException {
        UserRecord userRecord = FirebaseAuth.getInstance().getUserByEmail(email);
        if (userRecord.getEmail().equals(email)) {
            System.out.println("brugeren findes");
        } else {
            System.out.println("UserDTO findes ikke d: ");
        }
        return true;
    }


    public void validate(String uida) throws FirebaseAuthException {
        UserRecord userRecord = FirebaseAuth.getInstance().getUser(uida);
        boolean vali = (boolean) userRecord.getCustomClaims().get("admin");
        boolean vali1 = (boolean) userRecord.getCustomClaims().get("bruger");
        if (vali) {
            System.out.println("Dette er en admin ");
        } else if (vali1) {
            System.out.println("Dette er en bruger");
        } else {
            System.out.println("nejnej");
        }
    }

    public boolean validateToken(UserDTO userDTO) throws FirebaseAuthException {
        FirebaseToken token = FirebaseAuth.getInstance().verifyIdToken(userDTO.getUsername());
        return token.getUid() != null;
    }

    // henter en liste over alle brugere i systemet.
    public void getlist() throws FirebaseAuthException {
        ListUsersPage page = FirebaseAuth.getInstance().listUsers(null);
        while (page != null) {
            for (ExportedUserRecord user : page.getValues()) {
                System.out.println("UserDTO" + user.getEmail());
            }
            page = page.getNextPage();
        }

    }

    public boolean tjekCredentials(UserDTO userDTO) throws EnumCollectionMapException {
        ApiFuture<QuerySnapshot> data = FirestoreClient.getFirestore().collection(CollectionMap(CollectionKeys.USERS)).whereEqualTo("username", userDTO.getUsername()).get();
        QuerySnapshot userdata = null;
        try {
            userdata = data.get();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        List<UserDTO> userDTOS = userdata.toObjects(UserDTO.class);

        if (userDTOS.isEmpty()) {
            System.out.println("no userDTO found");
            return false;
        } else if (userDTOS.get(0).getPassword().equals(userDTO.getPassword())) {
            System.out.println(userDTO.getUsername() + " logget ind!");
            return true;
        } else {
            return false;
        }
    }

    public String makeToken(UserDTO userDTO, String UID) throws FirebaseAuthException {
        Map<String, Object> claims = new HashMap<>();
        claims.put("admin", true);

        FirebaseAuth.getInstance().setCustomUserClaims(UID, claims);
        String token = FirebaseAuth.getInstance().createCustomToken(userDTO.getUsername());
        return token;
    }

    public String getUID(String email) throws FirebaseAuthException {
        return FirebaseAuth.getInstance().getUserByEmail(email).getUid();
    }


    public boolean CreateUser(UserDTO userDTO) throws EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();
        CollectionReference docRef = db.collection(CollectionMap(CollectionKeys.USERS));

        //UserDTO user = getUserByUsername(userDTO.getUsername());

        /*
        if(user == null) {
            docRef.document().set(userDTO);
            return true;
        }else{
            throw new InputException("En bruger med username:" + userDTO.getUsername() + " Findes allerede.");
        }
         */

        docRef.document().set(userDTO);

        return false;
    }

    public UserDTO UpdateUser(UserDTO userDTO) throws ExecutionException, InterruptedException, EnumCollectionMapException {

        Firestore db = FirestoreClient.getFirestore();

        Map<String, Object> docData = new HashMap<>();
        docData.put("userId", userDTO.getUserId());
        docData.put("phone", userDTO.getPhone());
        docData.put("username", userDTO.getUsername());
        if(userDTO.getPassword() != null) {
            docData.put("password", userDTO.getPassword());
        }
        docData.put("email", userDTO.getEmail());
        docData.put("firstname", userDTO.getFirstname());
        docData.put("lastname", userDTO.getLastname());
        docData.put("companyID", userDTO.getCompanyID());


        ApiFuture<WriteResult> writeResult =
                db
                        .collection(CollectionMap(CollectionKeys.USERS))
                        .document(userDTO.getUserId())
                        .set(docData, SetOptions.merge());

        return getUserByUsername(userDTO.getUsername());
    }


    public UserDTO getUserByUsername(String username) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        Firestore db = FirestoreClient.getFirestore();

        ApiFuture<QuerySnapshot> docRef = db.collection(CollectionMap(CollectionKeys.USERS)).whereEqualTo("username", username).get();
// asynchronously retrieve the document
        List<UserDTO> document = docRef.get().toObjects(UserDTO.class);

        return document.get(0);
    }


    // Userlogind for at give FEEDBACK
    public boolean UserLoginAng(String pass) throws ExecutionException, InterruptedException {

        String jsonString = pass;
        HashMap<String, String> map = new Gson().fromJson(jsonString,
                new TypeToken<HashMap<String, String>>() {
                }.getType());

        System.out.println(map);
        String id = map.get("password");
        System.out.println(map.get("password"));
        Firestore db = FirestoreClient.getFirestore();


        DocumentReference docRef = db.collection("Meetings").document(id);
// asynchronously retrieve the document
        ApiFuture<DocumentSnapshot> future = docRef.get();
// ...
// future.get() blocks on response
        DocumentSnapshot document = future.get();
        if (document.exists()) {
            System.out.println("Document data: " + document.getData());
            return true;
        } else {
            System.out.println("No such document!");
            return false;
        }


    }






}