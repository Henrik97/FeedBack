package Login;

import brugerautorisation.data.Bruger;
import brugerautorisation.transport.rmi.Brugeradmin;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

public class BrugerautorisationRMI {

        public boolean tjekCredentials(String username, String password) throws RemoteException, NotBoundException, MalformedURLException {
            Brugeradmin ba = (Brugeradmin) Naming.lookup("rmi://javabog.dk/brugeradmin");
            Bruger bruger = ba.hentBruger(username, password);

            if(bruger != null){
                return true;
            }else{
                return false;
            }
        }

}
