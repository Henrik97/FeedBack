package RMIEndpoint;

import DTO.FeedbackBatchDTO;
import DTO.MeetingDTO;
import DTO.UserDTO;
import DTO.Virksomhed;
import Firebase.EnumCollectionMapException;
import Firebase.FirebaseFacilitator;
import Firebase.IFirebaseFacilitator;
import Firebase.InputException;
import com.google.firebase.auth.FirebaseAuthException;

import java.io.IOException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutionException;


public class RMIFirestoreImpl extends UnicastRemoteObject implements IFirebaseFacilitator {



    protected RMIFirestoreImpl() throws RemoteException {
        super(1617);
    }

    @Override
    public void init() throws IOException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        fire.init();
    }

    @Override
    public String setCustomQuestions(List<String> questionsArray) throws EnumCollectionMapException, RemoteException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.setCustomQuestions(questionsArray);
    }

    @Override
    public ArrayList<String> getQuestionsByMeetingID(String id) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.getQuestionsByMeetingID(id);
    }

    @Override
    public void tilføjVirksomhed(int virksomhedsID, String navn) throws InterruptedException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        fire.tilføjVirksomhed(virksomhedsID, navn);
    }

    @Override
    public void getMeetingCounter() {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        fire.getMeetingCounter();
    }

    @Override
    public Virksomhed HentVirksomhedMedId(int id) throws InterruptedException, ExecutionException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.HentVirksomhedMedId(id);
    }

    @Override
    public void opretmode(MeetingDTO meetingDTO) throws ParseException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        try {
            fire.opretmode(meetingDTO);
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Date addHoursToJavaUtilDate(Date date, int hours, int min) {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.addHoursToJavaUtilDate(date, hours, min);
    }

    @Override
    public MeetingDTO getMeetingByID(String id) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.getMeetingByID(id);
    }

    @Override
    public ArrayList<MeetingDTO> getAllMeetings() throws InterruptedException, ExecutionException, EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.getAllMeetings();
    }

    @Override
    public ArrayList<MeetingDTO> getAllMeetingsForUser(String userid, Boolean done) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.getAllMeetingsForUser(userid, done);
    }

    @Override
    public void setStateOfMeeting(String id, int state) throws ExecutionException, InterruptedException, EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
            fire.setStateOfMeeting(id, state);
    }

    @Override
    public Date setStartTimeOfMeeting(String id) throws ExecutionException, InterruptedException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.setStartTimeOfMeeting(id);
    }

    @Override
    public Date setEndTimeOfMeeting(String id) throws ExecutionException, InterruptedException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.setEndTimeOfMeeting(id);
    }

    @Override
    public void givFeedback(FeedbackBatchDTO batchDTO) throws EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        fire.givFeedback(batchDTO);
    }

    @Override
    public ArrayList<FeedbackBatchDTO> getFeedback(String id) throws ExecutionException, InterruptedException, EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.getFeedback(id);
    }

    @Override
    public boolean checkOmBrugerenFindes(String email) throws FirebaseAuthException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.checkOmBrugerenFindes(email);
    }

    @Override
    public void validate(String uida) throws FirebaseAuthException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        fire.validate(uida);
    }

    @Override
    public boolean validateToken(UserDTO userDTO) throws FirebaseAuthException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.validateToken(userDTO);
    }

    @Override
    public void getlist() throws FirebaseAuthException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        fire.getlist();
    }

    @Override
    public boolean tjekCredentials(UserDTO userDTO) throws EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.tjekCredentials(userDTO);
    }

    @Override
    public String getUID(String email) throws FirebaseAuthException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.getUID(email);
    }

    @Override
    public boolean CreateUser(UserDTO userDTO) throws EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.CreateUser(userDTO);
    }

    @Override
    public UserDTO UpdateUser(UserDTO userDTO) throws ExecutionException, InterruptedException, EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.UpdateUser(userDTO);
    }

    @Override
    public UserDTO getUserByUsername(String username) throws InterruptedException, ExecutionException, EnumCollectionMapException {
        FirebaseFacilitator fire = FirebaseFacilitator.getInstance();
        return fire.getUserByUsername(username);
    }
}
