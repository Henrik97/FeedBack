package RMIEndpoint;

import Firebase.IFirebaseFacilitator;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RemoteException;

public class RMIServer {

    private static String url = "rmi://[::]:1617/Feedback-backend";

    private boolean stated = false;

    private static RMIServer single_instance = null;


    // static method to create instance of Singleton class
    public static RMIServer getInstance()
    {
        if (single_instance == null)
            single_instance = new RMIServer();

        return single_instance;
    }

    private RMIServer(){

    }

    public synchronized void startRMIServer(){
        if(!stated) {
            stated = true;
            System.out.println("Publicerer over RMI.............");
            IFirebaseFacilitator impl = null;
            try {
                impl = new RMIFirestoreImpl();
            } catch (RemoteException e) {
                e.printStackTrace();
            }
            try {
                System.setProperty("java.rmi.server.hostname","127.0.0.1");
                java.rmi.registry.LocateRegistry.createRegistry(1617); // start rmiregistry i server-JVM

            } catch (RemoteException e) {
                e.printStackTrace();
            }
            try {
                Naming.rebind(url, impl);
            } catch (RemoteException e) {
                e.printStackTrace();
            } catch (MalformedURLException e) {
                e.printStackTrace();
            }
            System.out.println("Publiceret over RMI!");
        }
    }

}
