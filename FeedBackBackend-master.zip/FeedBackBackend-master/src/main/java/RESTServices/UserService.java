package RESTServices;

import DTO.UserDTO;
import Firebase.EnumCollectionMapException;
import Firebase.FirebaseFacilitator;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.concurrent.ExecutionException;

@Path("User")
public class UserService {

    FirebaseFacilitator fire = FirebaseFacilitator.getInstance();

    @POST
    @Path("/Opret")
    @Consumes(MediaType.APPLICATION_JSON)
    public boolean CreateUser(UserDTO userDTO){
        if (true) { // tjek om brugeren findes
            try {
                fire.CreateUser(userDTO);
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
            return true;
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
    }

    @POST
    @Path("/Update")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public UserDTO UpdateUser(UserDTO userDTO){
        if (true) { // tjek om brugeren findes
            try {
                return fire.UpdateUser(userDTO);
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }

    @POST
    @Path("/Delete/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean DeleteUser(@QueryParam("id") String id){
            try {
                System.out.println("slet " + id);
                return fire.deleteMeeting(id);
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }


}
