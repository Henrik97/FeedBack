package RESTServices;

import DTO.CommentDTO;
import DTO.FeedbackBatchDTO;
import DTO.MeetingDTO;
import Firebase.EnumCollectionMapException;
import Firebase.FirebaseFacilitator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.util.ArrayList;
import java.util.concurrent.ExecutionException;

@Path("Feedback")
public class FeedbackService {
    @Context
    HttpServletRequest request;
    @Context
    HttpServletResponse response;

    private FirebaseFacilitator fire = FirebaseFacilitator.getInstance();

    @POST
    @Path("/post")
    @Consumes(MediaType.APPLICATION_JSON)
    public void giveFeedback(FeedbackBatchDTO batchDTO){
        try {
            fire.givFeedback(batchDTO);
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }
    }

    @GET
    @Path("/isOpenforFeedback/{id}")
    public boolean isFeedbackOpen(@PathParam("id") String id){
        try {
            MeetingDTO meetingDTO = fire.getMeetingByID(id);
            System.out.println(meetingDTO.getState());
            if(meetingDTO.getState() == 2){
                return true;
            }else {
                return false;
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }
        return false;
    }

    @GET
    @Path("/{id}/Count")
    public int FeedbackCount(@PathParam("id") String id){
        try {
            return fire.getFeedback(id).size();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }
        return -1;
    }

    @GET
    @Path("/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<FeedbackBatchDTO> getFeedback(@PathParam("id") String id){
        try {
            return fire.getFeedback(id);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }
        return null;  // smid exsepetion.
    }

    @GET
    @Path("/Ordered/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<CommentDTO> getOrderedFeedback(@PathParam("id") String id){
        try {
            return fire.getOrderedFeedback(id);
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }
        return null;  // smid exsepetion.
    }

}