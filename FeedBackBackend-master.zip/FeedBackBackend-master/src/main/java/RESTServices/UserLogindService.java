package RESTServices;

import DTO.UserDTO;
import Firebase.EnumCollectionMapException;
import Firebase.FirebaseFacilitator;
import com.google.api.core.ApiFuture;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.DocumentSnapshot;
import com.google.cloud.firestore.Firestore;
import com.google.firebase.cloud.FirestoreClient;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;


@Path("nylog")
public class UserLogindService {
    @Context
    HttpServletRequest request;
    @Context
    HttpServletResponse response;


    FirebaseFacilitator fire = FirebaseFacilitator.getInstance();



    @POST
    @Path("CheckUserLogin")
    @Produces(MediaType.APPLICATION_JSON)
    public Boolean CheckUser(String UserID) throws IOException, ExecutionException, InterruptedException {

        fire.UserLoginAng(UserID);
        System.out.println(UserID);


        return fire.UserLoginAng(UserID);
    }





}



