package RESTServices;

import DTO.MeetingDTO;
import DTO.QuestionsDTO;
import DTO.UserPass;
import Firebase.EnumCollectionMapException;
import Firebase.FirebaseFacilitator;
import org.json.JSONObject;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;

@Path("Meeting")
public class MeetingService {
    @Context
    HttpServletRequest request;
    @Context
    HttpServletResponse response;


    FirebaseFacilitator fire = FirebaseFacilitator.getInstance();

    @GET
    @Path("/{meetingID}/Questions")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.TEXT_PLAIN)
    public Object[] getQuestions(@PathParam("meetingID") String id){
        System.out.println("ok");
        if (true) { // tjek om brugeren findes
            try {
                return fire.getQuestionsByMeetingID(id).toArray();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }

    @DELETE
    @Path("/{meetingID}")
    @Produces(MediaType.APPLICATION_JSON)
    @Consumes(MediaType.TEXT_PLAIN)
    public boolean DelMeeting(@PathParam("meetingID") String id){
        if (true) {
            try {
                return fire.deleteMeeting(id);
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }


    @GET
    @Path("/{meetingID}/Questions/{index}")
    @Produces(MediaType.TEXT_PLAIN)
    public String getOneQuestions(@PathParam("meetingID") String id,  @PathParam("index") int index){
        if (true) { // tjek om brugeren findes
            try {
                ArrayList<String> dto = fire.getQuestionsByMeetingID(id);
                return dto.get(index);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }


    @POST
    @Path("/Questions")
    @Produces(MediaType.APPLICATION_JSON)
    public HashMap setQuestionsHashmap(ArrayList<String> questions){
            try {
                HashMap<String, String> Spørgsmål1 = new HashMap<>();
                Spørgsmål1.put("QuestionID", fire.setCustomQuestions(questions));
                return Spørgsmål1;
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
            throw new WebApplicationException(Response.Status.FORBIDDEN);
    }

    @POST
    @Path("/Questions/Create")
    @Produces(MediaType.TEXT_PLAIN)
    @Consumes(MediaType.APPLICATION_JSON)
    public String setQuestions(QuestionsDTO questionsDTO){
        try {
            if(questionsDTO.getQuestions().size() > 0) {
                return fire.setCustomQuestions(questionsDTO.getQuestions());
            }
            throw new WebApplicationException(Response.Status.NO_CONTENT);
        } catch (EnumCollectionMapException e) {
            e.printStackTrace();
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }

    @GET
    @Path("/All")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<MeetingDTO> getAllMeetings(UserPass userPass){
        if (true) { // tjek om brugeren findes
            try {
                return fire.getAllMeetings();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }

    @GET
    @Path("/AllByUser/{userId}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<MeetingDTO> getAllMeetingsForUser(UserPass userPass, @PathParam("userId") String userId, @QueryParam("done") Boolean done){
        if (true) { // tjek om brugeren findes
            try {
                return fire.getAllMeetingsForUser(userId, done);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }


    @POST
    @Path("/{meetingID}/{state}")
    @Produces(MediaType.APPLICATION_JSON)
    public boolean SetStateOnMeeting(UserPass userPass, @PathParam("meetingID") String id, @PathParam("state") int state){
        if (true) { // tjek om brugeren findes
            try {
                fire.setStateOfMeeting(id, state);
                return true;
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }

    @POST
    @Path("/Start/{meetingID}")
    @Produces(MediaType.TEXT_PLAIN)
    public String StartMeeting(UserPass userPass, @PathParam("meetingID") String id){
        if (true) { // tjek om brugeren findes
            try {
                Date date = fire.setStartTimeOfMeeting(id);
                fire.setStateOfMeeting(id, 1); // 1 fordi mødet igangsættes.
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
                String dateString = format.format(date);
                return dateString;
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }


    @POST
    @Path("/End/{meetingID}")
    @Produces(MediaType.TEXT_PLAIN)
    public String StopMeeting(UserPass userPass, @PathParam("meetingID") String id){
        if (true) { // tjek om brugeren findes
            try {
                Date date = fire.setEndTimeOfMeeting(id);
                fire.setStateOfMeeting(id, 2); // 2 afsluttes. // åben for feedback
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
                String dateString = format.format(date);
                return dateString;
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }

    @POST
    @Path("/EndFeedback/{meetingID}")
    @Produces(MediaType.TEXT_PLAIN)
    public String StopFeedbackForMeeting(UserPass userPass, @PathParam("meetingID") String id){
        if (true) { // tjek om brugeren findes
            try {
                Date date = fire.setEndTimeOfMeeting(id);
                fire.setStateOfMeeting(id, 3); // 2 afsluttes. // åben for feedback
                SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSSZ");
                String dateString = format.format(date);
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (ExecutionException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
        throw new WebApplicationException(Response.Status.FORBIDDEN);
    }
/*
    @GET
    @Path("/{id}")
    @Produces("application/json")
    public String meetingsById(@PathParam("id") String id){
        if (true) { // tjek om brugeren findes
            try {
                return fire.getMeeting(id).getValue().toString();
            } catch (InterruptedException e) {
                e.printStackTrace();
                throw new WebApplicationException(Response.Status.FORBIDDEN);
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
    }


    @GET
    @Path("/{id}")
    @Produces("application/json")
    public String userINFO(@PathParam("id") String id){
        if (true) { // tjek om brugeren findes
            try {
                return fire.getMeeting(id).getValue().toString();
            } catch (InterruptedException e) {
                e.printStackTrace();
                throw new WebApplicationException(Response.Status.FORBIDDEN);
            }
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
    }

*/

    @POST
    @Path("/Opret")
    @Consumes(MediaType.APPLICATION_JSON)
    public boolean getAllMeetings(MeetingDTO meetingDTO){
        if (true) { // tjek om brugeren findes
            try {
                fire.opretmode(meetingDTO);
            } catch (ParseException e) {
                e.printStackTrace();
            } catch (EnumCollectionMapException e) {
                e.printStackTrace();
            }
            System.out.println(meetingDTO.getName());
            return true;
        } else {
            throw new WebApplicationException(Response.Status.FORBIDDEN);
        }
    }




}
