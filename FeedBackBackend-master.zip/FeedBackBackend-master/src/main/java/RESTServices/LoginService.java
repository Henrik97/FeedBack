package RESTServices;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response.Status;

import DTO.UserDTO;
import Firebase.EnumCollectionMapException;
import Firebase.FirebaseFacilitator;
import Login.BrugerautorisationRMI;
import Login.JWTHandler;

import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.concurrent.ExecutionException;


@Path("login")
public class LoginService {
	@Context
	HttpServletRequest request;
	@Context
	HttpServletResponse response;

	private FirebaseFacilitator fire = FirebaseFacilitator.getInstance();

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public UserDTO getLogin(UserDTO userDTO){
		BrugerautorisationRMI rmi = new BrugerautorisationRMI();

		boolean firebaselogin = false;
		try {
			firebaselogin = fire.tjekCredentials(userDTO);
		} catch (EnumCollectionMapException e) {
			e.printStackTrace();
		}
		if (firebaselogin) { // tjek om brugeren findes
			response.addHeader("Authorization", "Bearer " + JWTHandler.generateJwtToken(getUser(userDTO.getUsername())));
			try {
				return fire.getUserByUsername(userDTO.getUsername());
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			} catch (EnumCollectionMapException e) {
				e.printStackTrace();
			}
		} else {
			boolean RMILogin = false;
			try {
				RMILogin = rmi.tjekCredentials(userDTO.getUsername(), userDTO.getPassword());
				if(RMILogin){
					try {
						response.addHeader("Authorization", "Bearer " + JWTHandler.generateJwtToken(getUser(userDTO.getUsername())));
						return fire.getUserByUsername("Testbruger");
					} catch (InterruptedException e) {
						e.printStackTrace();
					} catch (ExecutionException e) {
						e.printStackTrace();
					} catch (EnumCollectionMapException e) {
						e.printStackTrace();
					}
				}
			} catch (RemoteException e) {
				e.printStackTrace();
			} catch (NotBoundException e) {
				e.printStackTrace();
			} catch (MalformedURLException e) {
				e.printStackTrace();
			}
		}
		throw new WebApplicationException(Status.FORBIDDEN);
	}

	@POST
	@Path("validate")
	public boolean validateToken(String token){
			try {
				JWTHandler.validateToken(token);
				return true;
			} catch (JWTHandler.AuthException e) {
				throw new WebApplicationException("Token invalid: " + e.getMessage(), 403);
			}


	}

	private UserDTO getUser(String userName) {
		return new UserDTO("", userName, "");
	}



	@GET
	@Path("test/{navn}/{password}")
	@Produces(MediaType.APPLICATION_JSON)
	public String login (@PathParam("navn") String navn, @PathParam("password") String password) {
		if (navn == "ole" && password == "sd") {
			System.out.println(navn);
			System.out.println(password);
			String token = "aidnad3";
			System.out.println(navn);
			System.out.println(password);
			// her skal den returnere en eller anden token
			return "{\"status\": \"" + token + "\"}";

		} else {
			System.out.println(navn);
			System.out.println(password);

			// her skal den returnere en eller anden token
			return navn + password;
		}
	}


}
