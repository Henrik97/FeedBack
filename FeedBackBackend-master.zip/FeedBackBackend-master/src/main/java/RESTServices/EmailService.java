package RESTServices;


import DTO.FeedbackBatchDTO;
import Email.SendnyMail;
import Firebase.EnumCollectionMapException;
import Login.BrugerautorisationRMI;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import javax.mail.MessagingException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.HashMap;
import java.util.concurrent.ExecutionException;


@Path("Email")
public class EmailService {
        @Context
        HttpServletRequest request;
        @Context
        HttpServletResponse response;


    SendnyMail mail = new SendnyMail();

    @POST
    @Path("/SendEmail")
    @Consumes(MediaType.APPLICATION_JSON)
    public void Sendmail(String Email){
        System.out.println("bliver kørt ");
        System.out.println(Email);


        String jsonString = Email;
        HashMap<String, String> map = new Gson().fromJson(jsonString,
                new TypeToken<HashMap<String, String>>() {
                }.getType());
        System.out.println(map);
        String nymail = map.get("email");
        String id = map.get("id1");
        System.out.println(id);


        try {
            mail.Nymail(nymail, id);
        } catch (MessagingException e) {
            e.printStackTrace();
        }

    }



}
