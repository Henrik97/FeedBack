package REST;

import RMIEndpoint.RMIServer;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;


//Defines api root
@ApplicationPath("/rest")
public class AppConfig extends Application {

    private static RMIServer rmiServer;

    static {
        rmiServer = RMIServer.getInstance();
        rmiServer.startRMIServer();
    }

}

