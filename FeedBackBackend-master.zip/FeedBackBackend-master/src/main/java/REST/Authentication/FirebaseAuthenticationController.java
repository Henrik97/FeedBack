package REST.Authentication;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.*;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutionException;

public class FirebaseAuthenticationController {

    private static final String UID = "hansen.dk@hotmail.com";


    public void init() throws IOException {
        FileInputStream serviceAccount = null;

        try {
            serviceAccount = new FileInputStream("KEYS/key.json");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        FirebaseOptions options = null;

        options = new FirebaseOptions.Builder()
                .setCredentials(GoogleCredentials.fromStream(serviceAccount))
                // .setDatabaseUrl("https://feedbackapp-2dacb.firebaseio.com/")
                //  .setServiceAccountId("my-client-id@my-project-id.iam.gserviceaccount.com")
                .build();

        FirebaseApp.initializeApp(options);
    }


    public String makeToken() throws FirebaseAuthException, ExecutionException, InterruptedException {
        // laver token her f
        Map<String, Object> additionalClaims = new HashMap<String, Object>();
        additionalClaims.put("premiumAccount", true);


        //  String customToken = FirebaseAuth.getInstance().createCustomTokenAsync(UID ,additionalClaims ).get();
        // System.out.println( "test "+customToken);


        String customToken = FirebaseAuth.getInstance().createCustomTokenAsync(UID, additionalClaims).get();
        // System.out.println( "test "+customToken);
        return customToken;
    }

    public void ha() throws FirebaseAuthException {

        UserRecord userRecord = FirebaseAuth.getInstance().getUserByEmail(UID);
        // See the UserRecord reference doc for the contents of userRecord.
        System.out.println("Successfully fetched user data: " + userRecord.getEmail());


        FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(userRecord.getUid());
        String uid = decodedToken.getUid();

        // to test metoder
        if(checkOmBrugerenFindes(UID)){
            System.out.println("ok");
        }

        getlist();
    }

    public boolean validateToken(String token) throws FirebaseAuthException {
       FirebaseToken stringtoken = FirebaseAuth.getInstance().verifyIdToken(token);
       if(stringtoken.getUid() != null){

           return true;
       }
       return false;
    }

    // checker om brugeren står i systemet via Email
public  static boolean checkOmBrugerenFindes (String email) throws FirebaseAuthException {

    UserRecord userRecord = FirebaseAuth.getInstance().getUserByEmail(email);
    if (userRecord.getEmail().equals(email)) {
        System.out.println("brugeren findes");
    } else {
        System.out.println("UserDTO findes ikke d: ");
    }
    return true;
}



        // henter en liste over alle brugere i systemet.
    public  static void getlist() throws FirebaseAuthException {
        ListUsersPage page = FirebaseAuth.getInstance().listUsers(null);
        while (page != null) {
            for (ExportedUserRecord user : page.getValues()) {
                System.out.println("UserDTO" +user.getEmail());
            }
            page = page.getNextPage();
        }

    }
}