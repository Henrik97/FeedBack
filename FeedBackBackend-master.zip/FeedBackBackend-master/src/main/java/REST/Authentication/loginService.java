package REST.Authentication;

import com.google.auth.oauth2.GoogleCredentials;
import com.google.firebase.FirebaseApp;
import com.google.firebase.FirebaseOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthException;
import com.google.firebase.auth.FirebaseToken;
import com.google.firebase.iid.FirebaseInstanceId;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.*;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;


@Path("ok")

public class loginService {


    @Context
    HttpServletRequest request;
    @Context
    HttpServletResponse response;


            //
    @POST
    @Path("/validate/{tokenid}")
    public String validateToken(@PathParam("tokenid")String tokenid) {
        try {

            System.out.println("okokok");
            FirebaseToken decodedToken = FirebaseAuth.getInstance().verifyIdToken(tokenid);
            String uid = decodedToken.getUid();
            System.out.println(uid);

            //FirebaseAuthentication.validate1(uid);
            return "Token valid!";
        } catch (FirebaseAuthException e) {
            e.printStackTrace();
            throw new WebApplicationException("Token invalid: " + e.getMessage(), 403);
        }
    }


        //Indtaster sit uid og den retournere en token.
    @GET
    @Path("/gettoken/{uid}")
    public String GivToken(@PathParam("uid") String uid) throws FirebaseAuthException {
        try {
            // kører firebase startdelen.
            FirebaseAuthentication.startmetode();

            // kører metoden
            FirebaseAuthentication.givToken(uid);


        } catch (FirebaseAuthException e) {
            e.printStackTrace();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return FirebaseAuthentication.givToken(uid) ;
    }




}
